import React, { useState } from 'react';


export function Services() {
  const [searchQuery, setSearchQuery] = useState('');
  const data = [
     
          {
            id: 1,
            name: "Colombo Central Police Station",
            telephone: "0112 421111",
            address: "No. 31, Janadhipathi Mawatha, Colombo 01",
          },
          {
            id: 2,
            name: "Fort Police Station",
            telephone: "0112 421444",
            address: "No. 18, Janadhipathi Mawatha, Colombo 01",
          },
          {
            id: 3,
            name: "Kollupitiya Police Station",
            telephone: "0112 421333",
            address: "No. 25, Police Park Avenue, Colombo 03",
          },
          {
            id: 4,
            name: "Wellawatte Police Station",
            telephone: "0112 421222",
            address: "No. 189, Galle Road, Colombo 06",
          },
          {
            id: 5,
            name: "Bambalapitiya Police Station",
            telephone: "0112 421555",
            address: "No. 59, W. A. Silva Mawatha, Colombo 06",
          },
          {
            id: 6,
            name: "Kirulapona Police Station",
            telephone: "0112 421777",
            address: "No. 267, Highlevel Road, Colombo 06",
          },
          {
            id: 7,
            name: "Narahenpita Police Station",
            telephone: "0112 421888",
            address: "No. 207, Kirimandala Mawatha, Colombo 05",
          },
          {
            id: 8,
            name: "Cinnamon Gardens Police Station",
            telephone: "0112 421999",
            address: "No. 20, Torrington Avenue, Colombo 07",
          },
          {
            id: 9,
            name: "Borella Police Station",
            telephone: "0112 421666",
            address: "No. 415, T. B. Jaya Mawatha, Colombo 08",
          },
          {
            id: 10,
            name: "Maradana Police Station",
            telephone: "0112 422222",
            address: "No. 62, Sangaraja Mawatha, Colombo 10",
          },
          {
            id: 11,
            name: "Pettah Police Station",
            telephone: "0112 422333",
            address: "No. 39, 1st Cross Street, Colombo 11",
          },
          {
            id: 12,
            name: "Slave Island Police Station",
            telephone: "0112 422444",
            address: "No. 90, Justice Akbar Mawatha, Colombo 02",
          },
          {
            id: 13,
            name: "Kotahena Police Station",
            telephone: "0112 422555",
            address: "No. 125, Jampettah Street, Colombo 13",
          },
          {
            id: 14,
            name: "Grandpass Police Station",
            telephone: "0112 422666",
            address: "No. 41, Ranasinghe Premadasa Mawatha, Colombo 14",
          },
          {
            id: 15,
            name: "Mattakkuliya Police Station",
            telephone: "0112 422777",
            address: "No. 41, Ranasinghe Premadasa Mawatha, Colombo 14",
          },
          {
               id: 16,
               name: "Angulana Police Station",
               telephone: "0112 423888",
               address: "No. 31/5, De Seram Road, Angulana",
             },
             {
               id: 17,
               name: "Mount Lavinia Police Station",
               telephone: "0112 343333",
               address: "No. 32, Hotel Road, Mount Lavinia",
             },
             {
               id: 18,
               name: "Ratmalana Police Station",
               telephone: "0112 423777",
               address: "No. 121, Galle Road, Ratmalana",
             },
             {
               id: 19,
               name: "Moratuwa Police Station",
               telephone: "0112 654111",
               address: "No. 220, Galle Road, Moratuwa",
             },
             {
               id: 20,
               name: "Nugegoda Police Station",
               telephone: "0112 281111",
               address: "No. 24, Stanley Thilakaratne Mawatha, Nugegoda",
             },
             {
               id: 21,
               name: "Homagama Police Station",
               telephone: "0112 859111",
               address: "No. 46, Colombo - Horana Road, Homagama"
             },
             {
               id: 22,
               name: "Kohuwala Police Station",
               telephone: "0112 810444",
               address: "No. 535, High Level Road, Nugegoda"
             },
             {
               id: 23,
               name: "Maharagama Police Station",
               telephone: "0112 850444",
               address: "No. 527, High Level Road, Maharagama"
             },
             {
               id: 24,
               name: "Nugegoda Police Station",
               telephone: "0112 810222",
               address: "No. 255, High Level Road, Nugegoda"
             },
             {
               id: 25,
               name: "Piliyandala Police Station",
               telephone: "0112 930333",
               address: "No. 246, Colombo - Horana Road, Piliyandala"
             },
             {
               id: 26,
               name: "Ratmalana Police Station",
               telephone: "0112 646444",
               address: "No. 137, Galle Road, Ratmalana"
             },
             {
               id: 27,
               name: "Kesbewa Police Station",
               telephone: "0112 857444",
               address: "No. 276, Old Road, Kesbewa"
             },
             {
               id: 28,
               name: "Kottawa Police Station",
               telephone: "0112 864444",
               address: "No. 451, High Level Road, Kottawa"
             },
             {
               id: 29,
               name: "Moratuwa Police Station",
               telephone: "0112 652444",
               address: "No. 207, Galle Road, Moratuwa"
             },
             {
               id: 30,
               name: "Panadura North Police Station",
               telephone: "0382 232222",
               address: "No. 174, Galle Road, Panadura"
             },
             {
               id: 31,
               name: "Panadura South Police Station",
               telephone: "0382 235444",
               address: "No. 2, Hirana Road, Panadura"
             },
             {
               id: 32,
               name: "Bandaragama Police Station",
               telephone: "0382 253111",
               address: "No. 99, Moronthuduwa Road, Bandaragama"
             },
             {
               id: 33,
               name: "Beruwala Police Station",
               telephone: "0342 222222",
               address: "No. 228, Galle Road, Beruwala"
             },
             {
               id: 34,
               name: "Kalutara North Police Station",
               telephone: "0342 222444",
               address: "No. 129, Galle Road, Kalutara North"
             },
             {
               id: 35,
               name: "Kalutara South Police Station",
               telephone: "0342 222666",
               address: "No. 413, Galle Road, Kalutara South"
             },
             {
               id: 36,
               name: "Kaduwela Police Station",
               telephone: "0112 448111",
               address: "No. 242, Colombo Road, Kaduwela"
             },
             
        
];


  const filteredData = data.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
     <div style={{ backgroundColor: 'grey', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
       <div class="container">
         <div class="m-3 text-center" style={{color: 'blue', fontSize: '24px'}}>Police station list</div>
   
         <input
           type="text"
           placeholder="Search by name"
           class="form-control"
           aria-label="Small"
           aria-describedby="inputGroup-sizing-sm"
           value={searchQuery}
           onChange={(e) => setSearchQuery(e.target.value)}
           style={{ maxWidth: "85%", margin: "0 auto" }}
         />
         <table class="table table-success table-striped table-dark" style={{ maxWidth: "85%", margin: "0 auto" }}>
           <thead>
             <tr>
               <th>#</th>
               <th>Name</th>
               <th>Telephone</th>
               <th>Address</th>
             </tr>
           </thead>
           <tbody>
             {filteredData.map((item) => (
               <tr key={item.id}>
                 <td>{item.id}</td>
                 <td>{item.name}</td>
                 <td>{item.telephone}</td>
                 <td>{item.address}</td>
               </tr>
             ))}
           </tbody>
         </table>
       </div>
     </div>
   );
             }   