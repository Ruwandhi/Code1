import React from "react";
import { Link } from "react-router-dom";
import { Slide } from "react-slideshow-image";
import "react-slideshow-image/dist/styles.css";
import { Card, Carousel } from "react-bootstrap"; // Import the Card component from Bootstrap
import backgrounda from "../pages/horse.jpg";
import backgroundb from "../pages/dog.jpg";
import backgroundc from "../pages/car.jpg";
import background from "../pages/images.jpg";
import backgroundp from "../pages/imagesp.jpg";
import backgroundq from "../pages/imagesq.jpg";
import backgroundr from "../pages/imagesr.jpg";
import backgrounds from "../pages/imagess.jpg";
import backgroundt from "../pages/imagest.jpg";
import backgroundu from "../pages/imagesu.jpg";
import backgroundv from "../pages/imagesv.jpg";

const divStyle = {
  backgroundSize: "cover",
  height: "400px",
  width: "1840px",
  position: "relative",
  textAlign: "center",
};

const slideStyle = {
  height: "100vh",
  width: "100%",
};

const slideImages = [
  {
    url: backgrounda,
  },
  {
    url: backgroundb,
  },
  {
    url: backgroundc,
  },
];

const Slideshow = () => {
  return (
    <div className="slide-container" style={{ top: "112px" }}>
      <Slide style={slideStyle}>
        {slideImages.map((slideImage, index) => (
          <div key={index}>
            <div
              style={{ ...divStyle, backgroundImage: `url(${slideImage.url})` }}
            ></div>
          </div>
        ))}
      </Slide>

      <div
        style={{
          position: "absolute",

          top: "500px",
          left: "582px",
          transform: "translate(-10%, -20%)",
          color: "white",
          fontSize: "34px",
          background: "#00000059",
          padding: "4px 22px",
        }}
      >
        welcome to online crime reporting system
      </div>
      <div>
        <div
          style={{
            position: "absolute",
            top: "290px",
            left: "40%",
            transform: "translate(-10%, -20%)",
            color: "white",
            fontSize: "34px",
            background: "#00000059",
            padding: "4px 22px",
            textAlign: "center",
          }}
        >
          <p>
            Have a Complaint!
            <br /> Sign Up now!
          </p>
          <Link
            style={{ top: "200px", left: "200px" }}
            class="nav-link mx-3"
            to="/SignUp"
          >
            <button class="btn btn-sm btn-primary" type="button">
              SignUp
            </button>
          </Link>
        </div>
      </div>
      {/* Add the Bootstrap card component */}
    </div>
  );
};
const SlideNews = () => {
  return (
    <Carousel
      pause={false}
      interval={5000}
      controls={false}
      indicators={false}
      style={{ top: "90px" }}
    >
      <Carousel.Item>
        <div className="row mt-3">
          <div className="col-sm"></div>
          <div className="col-sm">
            <Card
              style={{
                width: "18rem",
                height: "23rem",
                margin: "0",
                padding: "0",
                border: "none",
                maxHeight: "340px",
              }}
            >
              <Card.Img
                variant="top"
                src={background}
                style={{ height: "50%", objectFit: "cover" }}
              />
              <Card.Body style={{ padding: "1rem" }}>
                <Card.Title>News 1</Card.Title>
                <Card.Text>
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </Card.Text>
              </Card.Body>
            </Card>
          </div>
          <div className="col-sm">
            <Card
              style={{
                width: "18rem",
                height: "23rem",
                margin: "0",
                padding: "0",
                border: "none",
                maxHeight: "340px",
              }}
            >
              <Card.Img
                variant="top"
                src={backgroundp}
                style={{ height: "50%", objectFit: "cover" }}
              />
              <Card.Body style={{ padding: "1rem" }}>
                <Card.Title>News 2</Card.Title>
                <Card.Text>
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </Card.Text>
              </Card.Body>
            </Card>
          </div>
          <div className="col-sm">
            <Card
              style={{
                width: "18rem",
                height: "23rem",
                margin: "0",
                padding: "0",
                border: "none",
                maxHeight: "340px",
              }}
            >
              <Card.Img
                variant="top"
                src={backgroundq}
                style={{ height: "50%", objectFit: "cover" }}
              />
              <Card.Body style={{ padding: "1rem" }}>
                <Card.Title>News 3</Card.Title>
                <Card.Text>
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </Card.Text>
              </Card.Body>
            </Card>
          </div>
          <div className="col-sm">
            <Card
              style={{
                width: "18rem",
                height: "23rem",
                margin: "0",
                padding: "0",
                border: "none",
                maxHeight: "340px",
              }}
            >
              <Card.Img
                variant="top"
                src={backgroundr}
                style={{ height: "50%", objectFit: "cover" }}
              />
              <Card.Body style={{ padding: "1rem" }}>
                <Card.Title>News 4</Card.Title>
                <Card.Text>
                  A motorcyclist rides past a burnt bus toppled over an
                  artificial lake during demonstrations against the government
                  over Sri Lanka's crippling economic crisis in Colombo, May 11,
                  2022. Sri Lankan police have been ordered to go on the
                  offensive and use live ammunition to stop rioting. PHOTO: AFP
                </Card.Text>
              </Card.Body>
            </Card>
          </div>
          <div className="col-sm"></div>
        </div>
      </Carousel.Item>
      <Carousel.Item>
        <div className="row mt-3">
          <div className="col-sm"></div>
          <div className="col-sm">
            <Card
              style={{
                width: "18rem",
                height: "23rem",
                margin: "0",
                padding: "0",
                border: "none",
                maxHeight: "340px",
              }}
            >
              <Card.Img
                variant="top"
                src={backgrounds}
                style={{ height: "50%", objectFit: "cover" }}
              />
              <Card.Body style={{ padding: "1rem" }}>
                <Card.Title>News 5</Card.Title>
                <Card.Text>
                  Police last evening found a body of a 28 years old person who
                  had been cut to death by unidentified persons im
                  selverpuram,mullathiv.
                </Card.Text>
              </Card.Body>
            </Card>
          </div>
          <div className="col-sm">
            <Card
              style={{
                width: "18rem",
                height: "23rem",
                margin: "0",
                padding: "0",
                border: "none",
                maxHeight: "340px",
              }}
            >
              <Card.Img
                variant="top"
                src={backgroundt}
                style={{ height: "50%", objectFit: "cover" }}
              />
              <Card.Body style={{ padding: "1rem" }}>
                <Card.Title>News 6</Card.Title>
                <Card.Text>
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </Card.Text>
              </Card.Body>
            </Card>
          </div>
          <div className="col-sm">
            <Card
              style={{
                width: "18rem",
                height: "23rem",
                margin: "0",
                padding: "0",
                border: "none",
                maxHeight: "340px",
              }}
            >
              <Card.Img
                variant="top"
                src={backgroundu}
                style={{ height: "50%", objectFit: "cover" }}
              />
              <Card.Body style={{ padding: "1rem" }}>
                <Card.Title>News 7</Card.Title>
                <Card.Text>
                  A young motorcyclist and his fiancée were killed on New Year’s
                  day in the Bandaragama area in what police believed to be a
                  high-speed crash, the first fatal accident for 2022.
                </Card.Text>
              </Card.Body>
            </Card>
          </div>
          <div className="col-sm">
            <Card
              style={{
                width: "18rem",
                height: "23rem",
                margin: "0",
                padding: "0",
                border: "none",
                maxHeight: "340px",
              }}
            >
              <Card.Img
                variant="top"
                src={backgroundv}
                style={{ height: "50%", objectFit: "cover" }}
              />
              <Card.Body style={{ padding: "1rem" }}>
                <Card.Title>News 8</Card.Title>
                <Card.Text>
                  The ruins of the Avenra Garden Hotel after it was set on fire
                  in the unrest in Negambo Srilanka ,violence erupted in sri
                  Lanka on monday evening after the brother of president
                  Gotabaya Rajapaksha.
                </Card.Text>
              </Card.Body>
            </Card>
          </div>
          <div className="col-sm"></div>
        </div>
      </Carousel.Item>
    </Carousel>
  );
};

export function Home() {
  return (
    <div
    //     style={{backgroundColor:"antiquewhite"}}
    >
      <Slideshow />
      <SlideNews />
    </div>
  );
}
