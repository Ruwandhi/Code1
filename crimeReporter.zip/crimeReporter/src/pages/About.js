import background from "../pages/about.jpg";

export function About() {
  return (
    <div class="container" style={{maxWidth:"1400px"}}>
      <div class="row" style={{ marginTop: "135px" }}>
        <div
          class="col-md"
          style={{
            backgroundImage: `url(${background})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            height: "381px",
            width: "650px",
          }}
        ></div>
        <div class="col-md">
          <div
            style={{
              fontSize: "42px",
              textAlign: "center",
              backgroundColor: "black",
              color: "white",
            }}
          >
            About
          </div>
          <div style={{margin:"10px",fontSize:"18px", boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.5)", padding: "15px",paddingRight:"2px"}}>
  <p style={{ fontStyle: "italic" }}>
    An crime website is a website that deals specifically with crime
    or careers.Many crime websites are designed to allow employers to
    post job requirements for a position to be filled and are commonly
    known as job boards.Other crime sites offer employer
    reviwes,career and job- search advice and describe different job
    descriptions or employers.Through a job website a prospective
    employee can locate and fill out a job application or submit
    resumes over the Internet for the advertised position .The online
    career center was developed as a non- profit organization backed
    by forty major corporations allow job hunters to post their
    resumes and for recruiters to post job openings.
  </p>
</div>

        </div>
      </div>
    </div>
  );
}
