import React, { useState } from "react";
import { Col, Button, Row, Container, Card, Form } from "react-bootstrap";
import { Dropdown, DropdownButton } from "react-bootstrap";
// import background from '../pages/dog.jpg';

export function Complain() {
  const [contactNo, setContactNo] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    // handle form submission
  };

  const [selectedProvince, setSelectedProvince] = useState("");
  const [selectedDistrict, setSelectedDistrict] = useState("");
  const [selectedRegionalSecretariat, setSelectedRegionalSecretariat] =
    useState("");

  const handleProvinceSelect = (eventKey) => {
    setSelectedProvince(eventKey);
    setSelectedDistrict("");
    setSelectedRegionalSecretariat("");
  };

  const handleDistrictSelect = (eventKey) => {
    setSelectedDistrict(eventKey);
    setSelectedRegionalSecretariat("");
  };

  const handleRegionalSecretariatSelect = (eventKey) => {
    setSelectedRegionalSecretariat(eventKey);
  };

  return (
     <div style={{ 
          // backgroundImage: `linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url(${background})`,
          
        }}>
      <Container>
        <Row className="vh-100 d-flex justify-content-center .align-items-start">
          <Col md={8} lg={6} xs={12}>
            <Card className="px-4" style={{backgroundColor:"rgba(240, 248, 255, 0.65)", marginTop: "30px"}}>
              <Card.Body>
                <div className="mb-3 mt-md-4">
                  <h2 className="fw-bold mb-2 text-center">Report Crime</h2>
                  <div className="mb-3">
                    <Form onSubmit={handleSubmit}>
                      <Form.Group className="mb-3" controlId="userId">
                        <Form.Label className="text-center">
                          1. Enter your user ID
                        </Form.Label>
                        <Form.Control
                          type="text"
                          placeholder="User ID"
                          required
                        />
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="contactNo">
                        <Form.Label className="text-center">
                          2. Enter your Contact NO:
                        </Form.Label>
                        <Form.Control
                          type="tel"
                          placeholder="Enter contact number"
                          value={contactNo}
                          onChange={(event) => setContactNo(event.target.value)}
                          required
                          pattern="[0-9]{10}"
                        />
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="location">
                        <Form.Label className="text-center">
                          3. Enter Location of the crime
                        </Form.Label>
                        {/* <Form.Control
                          type="text"
                          placeholder="Location"
                          required
                        /> */}
                        <div>
                          <div className="container mt-3 ">
                            <div className="row mt-3">
                              <DropdownButton
                                id="dropdown-province"
                                title={`Select Province ${
                                  selectedProvince
                                    ? `(${selectedProvince})`
                                    : ""
                                }`}
                                onSelect={handleProvinceSelect}
                              >
                                <Dropdown.Item eventKey="Western">
                                  Western
                                </Dropdown.Item>
                                <Dropdown.Item eventKey="Central">
                                  Central
                                </Dropdown.Item>
                                <Dropdown.Item eventKey="Southern">
                                  Southern
                                </Dropdown.Item>
                                <Dropdown.Item eventKey="Northern">
                                  Northern
                                </Dropdown.Item>
                                <Dropdown.Item eventKey="Eastern">
                                  Eastern
                                </Dropdown.Item>
                                <Dropdown.Item eventKey="North Western">
                                  North Western
                                </Dropdown.Item>
                                <Dropdown.Item eventKey="North Central">
                                  North Central
                                </Dropdown.Item>
                                <Dropdown.Item eventKey="Uva">
                                  Uva
                                </Dropdown.Item>
                                <Dropdown.Item eventKey="Sabaragamuwa">
                                  Sabaragamuwa
                                </Dropdown.Item>
                              </DropdownButton>
                            </div>
                            <div className="row mt-3">
                              <DropdownButton
                                id="dropdown-district"
                                title={`Select District ${
                                  selectedDistrict
                                    ? `(${selectedDistrict})`
                                    : ""
                                }`}
                                onSelect={handleDistrictSelect}
                                disabled={!selectedProvince}
                              >
                                {selectedProvince === "Western" && (
                                  <>
                                    <Dropdown.Item eventKey="Colombo">
                                      Colombo
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Gampaha">
                                      Gampaha
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kalutara">
                                      Kalutara
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedProvince === "Central" && (
                                  <>
                                    <Dropdown.Item eventKey="Kandy">
                                      Kandy
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Matale">
                                      Matale
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Nuwara Eliya">
                                      Nuwara Eliya
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedProvince === "Southern" && (
                                  <>
                                    <Dropdown.Item eventKey="Galle">
                                      Galle
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Matara">
                                      Matara
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Hambantota">
                                      Hambantota
                                    </Dropdown.Item>
                                  </>
                                )}
                                {selectedProvince === "Northern" && (
                                  <>
                                    <Dropdown.Item eventKey="Jaffna">
                                      Jaffna
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kilinochchi">
                                      Kilinochchi
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mannar">
                                      Mannar
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mullaitivu">
                                      Mullaitivu
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Vavuniya">
                                      Vavuniya
                                    </Dropdown.Item>
                                  </>
                                )}
                                {selectedProvince === "Eastern" && (
                                  <>
                                    <Dropdown.Item eventKey="Batticaloa">
                                      Batticaloa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ampara">
                                      Ampara
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Trincomalee">
                                      Trincomalee
                                    </Dropdown.Item>
                                  </>
                                )}
                                {selectedProvince === "North Central" && (
                                  <>
                                    <Dropdown.Item eventKey="Anuradhapura">
                                      Anuradhapura
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Polonnaruwa">
                                      Polonnaruwa
                                    </Dropdown.Item>
                                  </>
                                )}
                                {selectedProvince === "Uva" && (
                                  <>
                                    <Dropdown.Item eventKey="Badull">
                                      Badull
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Monaragala">
                                      Monaragala
                                    </Dropdown.Item>
                                  </>
                                )}
                                {selectedProvince === "Sabaragamuwa" && (
                                  <>
                                    <Dropdown.Item eventKey="Kegalle">
                                      Kegalle
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ratnapura">
                                      Ratnapura
                                    </Dropdown.Item>
                                  </>
                                )}
                                {selectedProvince === "North Western" && (
                                  <>
                                    <Dropdown.Item eventKey="Kurunegal">
                                      Kurunegal
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Puttalam">
                                      Puttalam
                                    </Dropdown.Item>
                                  </>
                                )}
                              </DropdownButton>
                            </div>
                            <div className="row mt-3">
                              <DropdownButton
                                id="dropdown-regional-secretariat"
                                title={`Select Regional Secretariat ${
                                  selectedRegionalSecretariat
                                    ? `(${selectedRegionalSecretariat})`
                                    : ""
                                }`}
                                onSelect={handleRegionalSecretariatSelect}
                                disabled={!selectedDistrict}
                              >
                                {selectedDistrict === "Colombo" && (
                                  <>
                                    <Dropdown.Item eventKey="Colombo Central">
                                      Colombo Central
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Colombo North">
                                      Colombo North
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Colombo South">
                                      Colombo South
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Colombo West">
                                      Colombo West
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Gampaha" && (
                                  <>
                                    <Dropdown.Item eventKey="Attanagalla">
                                      Attanagalla
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Biyagama">
                                      Biyagama
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Divulapitiya">
                                      Divulapitiya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Dompe">
                                      Dompe
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Gampaha">
                                      Gampaha
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ja-Ela">
                                      Ja-Ela
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Katana">
                                      Katana
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kelaniya">
                                      Kelaniya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mahara">
                                      Mahara
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Minuwangoda">
                                      Minuwangoda
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mirigama">
                                      Mirigama
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Negombo">
                                      Negombo
                                    </Dropdown.Item>
                                  </>
                                )}
                                {selectedDistrict === "Kalutara" && (
                                  <>
                                    <Dropdown.Item eventKey="Agalawatta">
                                      Agalawatta
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Bandaragama">
                                      Bandaragama
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Beruwala">
                                      Beruwala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Bulathsinhala">
                                      Bulathsinhala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Horana">
                                      Horana
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ingiriya">
                                      Ingiriya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kalutara North">
                                      Kalutara North
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kalutara South">
                                      Kalutara South
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Matugama">
                                      Matugama
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Kandy" && (
                                  <>
                                    <Dropdown.Item eventKey="Akurana">
                                      Akurana
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Gampola">
                                      Gampola
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kandy Four Gravets and Gangawata Korale">
                                      Kandy Four Gravets and Gangawata Korale
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kundasale">
                                      Kundasale
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Medadumbara">
                                      Medadumbara
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Nawalapitiya">
                                      Nawalapitiya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Pathadumbara">
                                      Pathadumbara
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Senkadagala">
                                      Senkadagala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Teldeniya">
                                      Teldeniya
                                    </Dropdown.Item>
                                  </>
                                )}
                                {selectedDistrict === "Matale" && (
                                  <>
                                    <Dropdown.Item eventKey="Dambulla">
                                      Dambulla
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Galewela">
                                      Galewela
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Laggala - Pallegama">
                                      Laggala - Pallegama
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Matale">
                                      Matale
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Pallepola">
                                      Pallepola
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Rattota">
                                      Rattota
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ukuwela">
                                      Ukuwela
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Wilgamuwa">
                                      Wilgamuwa
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Nuwara Eliya" && (
                                  <>
                                    <Dropdown.Item eventKey="Maskeliya">
                                      Maskeliya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kothmale">
                                      Kothmale
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ambagamuwa">
                                      Ambagamuwa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Nuwara Eliya">
                                      Nuwara Eliya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Walapane">
                                      Walapane
                                    </Dropdown.Item>
                                  </>
                                )}
                                {selectedDistrict === "Galle" && (
                                  <>
                                    <Dropdown.Item eventKey="Akmeemana">
                                      Akmeemana
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ambalangoda">
                                      Ambalangoda
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Balapitiya">
                                      Balapitiya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Bentota">
                                      Bentota
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Elpitiya">
                                      Elpitiya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Habaraduwa">
                                      Habaraduwa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Karandeniya">
                                      Karandeniya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Nagoda">
                                      Nagoda
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Rathgama">
                                      Rathgama
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Matara" && (
                                  <>
                                    <Dropdown.Item eventKey="Akuressa">
                                      Akuressa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Devinuwara">
                                      Devinuwara
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Hakmana">
                                      Hakmana
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kamburupitiya">
                                      Kamburupitiya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Matara">
                                      Matara
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Thihagoda">
                                      Thihagoda
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Weligama">
                                      Weligama
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Hambantota" && (
                                  <>
                                    <Dropdown.Item eventKey="Ambalantota">
                                      Ambalantota
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Angunakolapelessa">
                                      Angunakolapelessa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Beliatta">
                                      Beliatta
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Hambantota">
                                      Hambantota
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Lunugamvehera">
                                      Lunugamvehera
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mulkirigala">
                                      Mulkirigala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Tangalle">
                                      Tangalle
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Tissamaharama">
                                      Tissamaharama
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Jaffna" && (
                                  <>
                                    <Dropdown.Item eventKey="Chavakachcheri">
                                      Chavakachcheri
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Jaffna">
                                      Jaffna
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Karaveddy">
                                      Karaveddy
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kilinochchi">
                                      Kilinochchi
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mullaitivu">
                                      Mullaitivu
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Point Pedro">
                                      Point Pedro
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Kilinochchi" && (
                                  <>
                                    <Dropdown.Item eventKey="Karachchi">
                                      Karachchi
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kilinochchi">
                                      Kilinochchi
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Poonakary">
                                      Poonakary
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Mannar" && (
                                  <>
                                    <Dropdown.Item eventKey="Madhu">
                                      Madhu
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mannar">
                                      Mannar
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Musali">
                                      Musali
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Mullaitivu" && (
                                  <>
                                    <Dropdown.Item eventKey="Maritimepattu">
                                      Maritimepattu
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mullaitivu">
                                      Mullaitivu
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Oddusuddan">
                                      Oddusuddan
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Vavuniya" && (
                                  <>
                                    <Dropdown.Item eventKey="Vavuniya North">
                                      Vavuniya North
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Vavuniya South">
                                      Vavuniya South
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Vengalacheddikulam">
                                      Vengalacheddikulam
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Batticaloa" && (
                                  <>
                                    <Dropdown.Item eventKey="Eravur">
                                      Eravur
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kattankudy">
                                      Kattankudy
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Batticaloa">
                                      Batticaloa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Valaichchenai">
                                      Valaichchenai
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Ampara" && (
                                  <>
                                    <Dropdown.Item eventKey="Addalaichenai">
                                      Addalaichenai
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Akkaraipattu">
                                      Akkaraipattu
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Alayadiwembu">
                                      Alayadiwembu
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Damana">
                                      Damana
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Dehiattakandiya">
                                      Dehiattakandiya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Lahugala">
                                      Lahugala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mahaoya">
                                      Mahaoya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Padiyathalawa">
                                      Padiyathalawa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Samanthurai">
                                      Samanthurai
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Uhana">
                                      Uhana
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Trincomalee" && (
                                  <>
                                    <Dropdown.Item eventKey="Kantalai">
                                      Kantalai
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kinniya">
                                      Kinniya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Muttur">
                                      Muttur
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Seruvila">
                                      Seruvila
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Trincomalee Town and Gravets">
                                      Trincomalee Town and Gravets
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Kurunegala" && (
                                  <>
                                    <Dropdown.Item eventKey="Alawwa">
                                      Alawwa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Bingiriya">
                                      Bingiriya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Galgamuwa">
                                      Galgamuwa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Giribawa">
                                      Giribawa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ibbagamuwa">
                                      Ibbagamuwa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kuliyapitiya">
                                      Kuliyapitiya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kurunegala">
                                      Kurunegala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mawathagama">
                                      Mawathagama
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Narammala">
                                      Narammala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Polgahawela">
                                      Polgahawela
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Puttalam" && (
                                  <>
                                    <Dropdown.Item eventKey="Anamaduwa">
                                      Anamaduwa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Arachchikattuwa">
                                      Arachchikattuwa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Chilaw">
                                      Chilaw
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Karuwalagaswewa">
                                      Karuwalagaswewa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Nawagattegama">
                                      Nawagattegama
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Pallama">
                                      Pallama
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Puttalam">
                                      Puttalam
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Anuradhapura" && (
                                  <>
                                    <Dropdown.Item eventKey="Anuradhapura DS">
                                      Anuradhapura DS
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Galenbindunuwewa DS">
                                      Galenbindunuwewa DS
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Horowpothana DS">
                                      Horowpothana DS
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ipalogama DS">
                                      Ipalogama DS
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kahatagasdigiliya DS">
                                      Kahatagasdigiliya DS
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kebithigollewa DS">
                                      Kebithigollewa DS
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kekirawa DS">
                                      Kekirawa DS
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Medawachchiya DS">
                                      Medawachchiya DS
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mihinthale DS">
                                      Mihinthale DS
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Nachchadoowa DS">
                                      Nachchadoowa DS
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Polonnaruwa" && (
                                  <>
                                    <Dropdown.Item eventKey="Dimbulagala">
                                      Dimbulagala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Elahera">
                                      Elahera
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Hingurakgoda">
                                      Hingurakgoda
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Lankapura">
                                      Lankapura
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Medirigiriya">
                                      Medirigiriya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Thamankaduwa">
                                      Thamankaduwa
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Badulla" && (
                                  <>
                                    <Dropdown.Item eventKey="Badulla Town">
                                      Badulla Town
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Bandarawela">
                                      Bandarawela
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ella">
                                      Ella
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Haldummulla">
                                      Haldummulla
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Haputale">
                                      Haputale
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mahiyanganaya">
                                      Mahiyanganaya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Meegahakivula">
                                      Meegahakivula
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Passara">
                                      Passara
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Welimada">
                                      Welimada
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Monaragala" && (
                                  <>
                                    <Dropdown.Item eventKey="Bibile">
                                      Bibile
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Buttala">
                                      Buttala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kataragama">
                                      Kataragama
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Madulla">
                                      Madulla
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Medagama">
                                      Medagama
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Monaragala">
                                      Monaragala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Sevanagala">
                                      Sevanagala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Wellawaya">
                                      Wellawaya
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Kegalle" && (
                                  <>
                                    <Dropdown.Item eventKey="Aranayaka">
                                      Aranayaka
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Bulathkohupitiya">
                                      Bulathkohupitiya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Dehiowita">
                                      Dehiowita
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Deraniyagala">
                                      Deraniyagala
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Galigamuwa">
                                      Galigamuwa
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kegalle">
                                      Kegalle
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Mawanella">
                                      Mawanella
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Rambukkana">
                                      Rambukkana
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ruwanwella">
                                      Ruwanwella
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Yatiyanthota">
                                      Yatiyanthota
                                    </Dropdown.Item>
                                  </>
                                )}

                                {selectedDistrict === "Ratnapura" && (
                                  <>
                                    <Dropdown.Item eventKey="Balangoda">
                                      Balangoda
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Eheliyagoda">
                                      Eheliyagoda
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Embilipitiya">
                                      Embilipitiya
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Kuruwita">
                                      Kuruwita
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Pelmadulla">
                                      Pelmadulla
                                    </Dropdown.Item>
                                    <Dropdown.Item eventKey="Ratnapura">
                                      Ratnapura
                                    </Dropdown.Item>
                                  </>
                                )}
                              </DropdownButton>
                            </div>
                          </div>
                        </div>
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="crimeMedia">
                        <Form.Label className="text-center">
                          4. Upload a photo or video of the crime
                        </Form.Label>
                        <Form.Control
                          type="file"
                          accept="image/*,video/*"
                          required
                        />
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="crimeMedia">
                        <Form.Label className="text-center">
                          4. Description of the crime
                        </Form.Label>
                        <Form.Control
                          as="textarea"
                          placeholder="Description"
                          rows={5}
                          required
                        />
                      </Form.Group>

                      <div className="d-grid">
                        <Button variant="primary" type="submit">
                          Submit
                        </Button>
                      </div>
                    </Form>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}
