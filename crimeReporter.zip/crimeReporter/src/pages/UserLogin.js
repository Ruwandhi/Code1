import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Col, Button, Row, Container, Card, Form } from 'react-bootstrap';
// import background from '../pages/dog.jpg';

export function UserLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    // process the form submission
  };

  return (
     <div style={{ 
          // backgroundImage: `linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url(${background})`,
        }}>
        
      <Container>
        <Row className="vh-100 d-flex justify-content-center align-items-center">
          <Col md={8} lg={6} xs={12}>
            <Card className="px-4" style={{backgroundColor: "rgba(240, 248, 255, 0.65)", marginTop: "-50%"}}>
              <Card.Body>
                <div className="mb-3 mt-md-4">
                  <h2 className="fw-bold mb-2 text-center">
                    Log In
                  </h2>
                  <div className="mb-3">
                    <Form onSubmit={handleSubmit}>
                      <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label className="text-center" style={{fontWeight: "bold"}}>
                          Email address
                        </Form.Label>
                        <Form.Control 
                          type="email" 
                          placeholder="Enter email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                        />
                      </Form.Group>

                      <Form.Group
                        className="mb-3"
                        controlId="formBasicPassword"
                      >
                        <Form.Label style={{fontWeight: "bold"}}>Password</Form.Label>
                        <Form.Control 
                          type="password" 
                          placeholder="Password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          required
                        />
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="formBasicCheckbox">
                        <Form.Check 
                          type="checkbox" 
                          label="Remember me" 
                          checked={rememberMe} 
                          onChange={(e) => setRememberMe(e.target.checked)}
                          style={{fontWeight: "bold"}}
                        />
                      </Form.Group>
                      
                      <div className="d-grid">
                        <Button variant="primary" type="submit">
                          Sign In
                        </Button>
                      </div>
                    </Form>
                    <div className="mt-3">
                      <p className="mb-0  text-center" style={{fontWeight: "bold"}}>
                        Don't have an account yet?{' '}
                        <Link to="/SignUp" className="text-primary fw-bold">
                          Sign Up
                        </Link>
                      </p>
                    </div>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}
