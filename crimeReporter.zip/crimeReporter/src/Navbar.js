import React from "react";
import { Link, Route, Routes } from "react-router-dom";
import { Complain } from "./pages/Complain";
import { Services } from "./pages/Services";
import { UserLogin } from "./pages/UserLogin";
import { SignUp } from "./pages/SignUp";
import { Home } from "./pages/Home";
import { About } from "./pages/About";
import { CrimeDetails } from "./pages/CrimeDetails";
import logo from "./pages/police.png"; // import your image

const Navbar = () => {
  return (
    <div>
      <nav class="navbar sticky-top navbar-expand-sm navbar-light bg-info">
        <div class="container-fluid justify-content-end">
          <img src={logo} alt="Logo" style={{ marginLeft: "30px" }} />
          <a
            class="navbar-brand"
            href="#"
            style={{ fontSize: "25px", fontWeight: "bold", marginLeft: "15px" }}
          >
            CrimeReporter
          </a>
          <ul class="navbar-nav w-100  justify-content-center">
            <li class="nav-item">
              <Link class="nav-link mx-3" to="/">
                Home
              </Link>
            </li>
            <li class="nav-item ">
              <Link class="nav-link mx-3" to="/About"> 
                About
              </Link>
            </li>
            <li class="nav-item">
              <Link class="nav-link mx-3" to="/Complain">
                Complain
              </Link>
            </li>
            <li class="nav-item">
              <Link class="nav-link mx-3" to="/SCrimeDetails">
                Crimes
              </Link>
            </li>
            <li class="nav-item">
              <Link class="nav-link mx-3" to="/Services">
                Services
              </Link>
            </li>
            <li class="nav-item ">
              <Link class="nav-link mx-3" to="/UserLogin">
              <button class="btn btn-sm btn-primary" type="button">Login</button>
              </Link>
            </li>
            
            {/* <li class="nav-item ">
              <Link class="nav-link mx-3" to="/SignUp">
                <button class="btn btn-sm btn-primary" type="button">
                  SignUp
                </button>
              </Link>
            </li> */}
          </ul>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Complain" element={<Complain />} />
        <Route path="/CrimeDetails" element={<CrimeDetails />} />
        <Route path="/Services" element={<Services />} />
        <Route path="/UserLogin" element={<UserLogin />} />
        <Route path="/SignUp" element={<SignUp />} />
        <Route path="/About" element={<About />} />
      </Routes>
    </div>
  );
};

export default Navbar;
