package com.crimereporter.crimereport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrimeReportApplicationTests {

    @Test
    void contextLoads() {
    }

}
