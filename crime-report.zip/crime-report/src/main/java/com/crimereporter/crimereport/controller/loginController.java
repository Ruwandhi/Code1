package com.crimereporter.crimereport.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class loginController {

    @PostMapping("/login")
    public String login(HttpSession httpSession) {
        return "test";
    }

    @PostMapping("/signup")
    public String signup(HttpSession httpSession) {
        String name  = "banda";
        return name;
    }
}
